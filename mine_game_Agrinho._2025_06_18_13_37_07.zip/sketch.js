let player;
let items = [];
let score = 0;
let itemInterval = 60;

function setup() {
  createCanvas(600, 400);
  player = new Player();
}

function draw() {
  background(120, 200, 120); // verde do campo

  // desenha linha que separa cidade
  fill(100);
  rect(0, 0, width, 100);
  fill(255);
  textSize(16);
  text("Cidade", 10, 20);
  text("Campo", 10, 120);

  player.update();
  player.show();

  // gerar itens
  if (frameCount % itemInterval === 0) {
    items.push(new FallingItem());
  }

  for (let i = items.length - 1; i >= 0; i--) {
    items[i].update();
    items[i].show();

    if (items[i].hits(player)) {
      if (items[i].type === 'campo') {
        score += 10;
      } else {
        score -= 5;
      }
      items.splice(i, 1);
    } else if (items[i].offscreen()) {
      items.splice(i, 1);
    }
  }

  fill(0);
  textSize(20);
  text("Pontuação: " + score, 400, 30);
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    player.move(-1);
  } else if (keyCode === RIGHT_ARROW) {
    player.move(1);
  }
}

// Player
class Player {
  constructor() {
    this.x = width / 2;
    this.size = 60;
    this.speed = 80;
  }

  move(dir) {
    this.x += dir * this.speed;
    this.x = constrain(this.x, 0, width - this.size);
  }

  update() {}

  show() {
    fill(255, 200, 0);
    rect(this.x, height - this.size, this.size, this.size);
    fill(0);
    textSize(12);
    textAlign(CENTER);
    text("👨‍🌾", this.x + this.size / 2, height - this.size / 2 + 5);
  }
}

// Itens caindo
class FallingItem {
  constructor() {
    this.x = random(width);
    this.y = 0;
    this.size = 30;
    this.speed = random(2, 5);
    this.type = random() > 0.5 ? 'campo' : 'cidade';
  }

  update() {
    this.y += this.speed;
  }

  show() {
    textSize(24);
    textAlign(CENTER);
    if (this.type === 'campo') {
      text(random(['🌽', '🥕', '🍅']), this.x, this.y);
    } else {
      text(random(['💨', '🛢️', '🗑️']), this.x, this.y);
    }
  }

  hits(player) {
    return (this.y > height - player.size &&
            this.x > player.x &&
            this.x < player.x + player.size);
  }

  offscreen() {
    return this.y > height;
  }
}
